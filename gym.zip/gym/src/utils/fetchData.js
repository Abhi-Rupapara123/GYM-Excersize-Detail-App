export const exerciseOptions = {
  method: "GET",
  headers: {
    "x-rapidapi-host": "exercisedb.p.rapidapi.com",
    "x-rapidapi-key": "6a014db31fmshbf4c9f15d4bbf36p1b9be4jsn3b5a15cbfb3b",
  },
};

export const youtubeOptions = {
  method: "GET",
  headers: {
    "X-RapidAPI-Host": "youtube-search-and-download.p.rapidapi.com",
    "X-RapidAPI-Key": "f0021db587msh781fb1cbef39856p11c183jsn45521d5d1c85",
  },
};

export const fetchData = async (url, options) => {
  console.log(url, options, "abhay11fe");
  const res = await fetch(url, options);
  console.log(res, "abhay res");
  const data = await res.json();

  return data;
};
